"""Core execution engine."""
