"""code_coverage skill package."""
