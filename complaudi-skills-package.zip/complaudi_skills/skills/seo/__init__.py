"""seo skill package."""
