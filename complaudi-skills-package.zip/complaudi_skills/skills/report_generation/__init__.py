"""report_generation skill package."""
