"""ios skill package."""
