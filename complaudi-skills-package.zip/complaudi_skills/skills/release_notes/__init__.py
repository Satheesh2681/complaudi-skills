"""release_notes skill package."""
