"""android skill package."""
