"""mock_testing skill package."""
