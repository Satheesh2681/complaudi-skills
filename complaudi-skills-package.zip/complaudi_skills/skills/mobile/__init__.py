"""mobile skill package."""
