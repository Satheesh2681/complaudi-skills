"""Standalone Complaudi assessment skills extension."""
