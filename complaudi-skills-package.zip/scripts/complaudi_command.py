#!/usr/bin/env python3
"""Start an authenticated Complaudi website audit and wait for its dashboard result."""
import argparse
import json
import os
import getpass
import sys
import time
import urllib.error
import urllib.request


def request(url, token, method="GET", payload=None):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode())
    except urllib.error.HTTPError as exc:
        try:
            body = json.loads(exc.read().decode())
            message = body.get("error", {}).get("message", str(exc))
        except Exception:
            message = str(exc)
        raise RuntimeError(f"Complaudi API returned HTTP {exc.code}: {message}") from exc


def main():
    parser = argparse.ArgumentParser(description="Run the integrated Complaudi website audit")
    parser.add_argument("--url", help="Authorized website URL")
    parser.add_argument("--deep", action="store_true", help="Enable the bounded same-origin deep crawl")
    parser.add_argument("--include-source", action="store_true", help="Also scan the source root configured on the API server")
    args = parser.parse_args()
    url = args.url or input("Website URL to audit: ").strip()
    if not url:
        parser.error("A website URL is required")
    base = os.environ.get("COMPLAUDI_API_BASE_URL", "http://localhost:4000").rstrip("/")
    token = os.environ.get("COMPLAUDI_API_TOKEN", "") or getpass.getpass("Complaudi API access token (input hidden): ").strip()
    if not token:
        print("An API access token is required.", file=sys.stderr)
        return 2
    api = base + "/api/v1/website-audits"
    created = request(api, token, "POST", {"url": url, "deep": args.deep, "includeSource": args.include_source})
    run = created.get("run", {})
    run_id = run.get("id")
    if not run_id:
        raise RuntimeError("The API did not return an audit run ID")
    print(f"Complaudi audit started: {run_id}")
    print("Dashboard: /website-audit")
    while True:
        current = request(api + "/" + run_id, token).get("run", {})
        status = current.get("status")
        print(f"Status: {status}", flush=True)
        if status in ("COMPLETED", "FAILED"):
            if status == "FAILED":
                print(current.get("errorMessage") or "Audit failed", file=sys.stderr)
                return 1
            counts = current.get("statusCounts") or {}
            for key in ("PASS", "FAIL", "WARN", "NOT_RUN", "NEEDS_API"):
                print(f"{key}: {counts.get(key, 0)}")
            print("Open the Complaudi dashboard and select Website Audit to inspect all findings.")
            return 0
        time.sleep(3)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Polling stopped. The server-side audit may continue; check /website-audit.", file=sys.stderr)
        raise SystemExit(130)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
