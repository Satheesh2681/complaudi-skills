Run the Complaudi assessment pipeline against the current local project directory.

1. Determine the current working directory and verify that `complaudi_skills/core/engine.py` exists.
2. Execute the engine with Python 3 from the current project root:
   `python3 -m complaudi_skills.core.engine --project .`
3. Stream the command output to the terminal and summarize the final PASS/WARN/FAIL counts and report paths.
4. Do not edit, format, install dependencies into, reset, stash, checkout, commit, push, or deploy the application source. The engine is read-only except for its own `complaudi_skills/reports/` outputs and the generated release-notes file under that extension.
5. If Python 3 is unavailable, explain the prerequisite. Do not silently substitute a different command.

The engine sequence is: local code checkout validation (no Git checkout/reset), build/compilation, Code Coverage/Unit Testing, Security Checker, Performance Testing, SEO, UAT Testing, Mock Testing, Security Testing, Mobile Compatibility, iOS, Android, Release Notes/Feature Versioning, and Report Generation. Build failure stops later stages. Individual skill failures are recorded and later safe checks continue.
