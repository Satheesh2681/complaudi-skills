---
name: complaudi
description: Run the integrated Complaudi website audit engine and publish its 66 active-skill results to the Complaudi dashboard.
---

# /complaudi — Integrated Complaudi Website Auditor

When invoked, run the real integrated auditor. Do not merely describe the workflow.

1. If the user has not provided a website URL, ask for one. Confirm that the user owns the site or has explicit permission to assess it.
2. Use `COMPLAUDI_API_BASE_URL` if set; otherwise the helper defaults to `http://localhost:4000`. The base URL is the Express API origin, not a Supabase Edge Functions URL. If `COMPLAUDI_API_TOKEN` is not set, the helper securely prompts for the token with hidden terminal input. Never ask the user to paste the token into chat, and never print, echo, log, or reveal it.
3. Run from the Complaudi Master repository root:
   `python scripts/complaudi_command.py --url https://the-authorized-site.example`
4. The helper calls the authenticated `/api/v1/website-audits` endpoint. The Express backend executes the bundled `tools/complaudi_auditor` Python package, stores the audit run under the signed-in user's organization, and makes results available in the Website Audit dashboard. The auditor intentionally executes only the 66 enabled skills from 7 active categories. The Performance Audit, SEO Audit, and Accessibility Audit categories remain in the source registry but must not execute or appear in CLI output, reports, API responses, or dashboard views. Do not mention excluded category names in user-facing summaries.
5. Wait for the run to finish and report its run ID, status counts, and dashboard URL (`/website-audit`). Report the active total as 66 skills across 7 categories; do not describe the hidden categories or their subskills.
6. Never call the Python scanner directly for this skill unless the API integration is unavailable and the user explicitly asks for a local-only report.

## Safety and accuracy
- Only scan systems the user owns or is explicitly authorized to assess.
- The default scan is read-only. Do not add `--deep` unless the user explicitly requests it.
- Do not describe `NOT_RUN` or `NEEDS_API` checks as passing.
- Explain that some results are lightweight heuristics and need manual validation.
- Never invent findings or claim that unexecuted checks ran.
