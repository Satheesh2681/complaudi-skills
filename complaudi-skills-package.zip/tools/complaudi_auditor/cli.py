import argparse, sys
from pathlib import Path
from .registry import ACTIVE_SKILLS, ACTIVE_TOTAL_SKILLS
from .checks import run_website, run_source, result
from .report import write_reports

def main():
    p=argparse.ArgumentParser(prog="complaudi",description="Read-only Complaudi website/source auditor")
    p.add_argument("--url",help="Public website URL, e.g. https://complaudi.in")
    p.add_argument("--source",help="Local source-code directory or file")
    p.add_argument("--output",default="reports",help="Report output directory (default: reports)")
    p.add_argument("--deep",action="store_true",help="Check up to 25 same-origin links and four fixed exposure paths")
    p.add_argument("--list-skills",action="store_true",help="Print the 66 enabled skills")
    args=p.parse_args()
    if args.list_skills:
        for cat,skills in ACTIVE_SKILLS.items():
            print(f"\n{cat} ({len(skills)})")
            for i,s in enumerate(skills,1): print(f"  {i}. {s}")
        print(f"\nActive skills: {ACTIVE_TOTAL_SKILLS}")
        return 0
    if not args.url and not args.source:
        p.error("Provide --url and/or --source. Example: python -m complaudi_auditor --url https://complaudi.in --source ./project")
    results=[]; meta={}
    if args.url:
        print(f"[+] Website scan: {args.url}")
        wr,_,wm=run_website(args.url,args.deep); results.extend(wr); meta["website"]=wm
    if args.source:
        if not Path(args.source).exists(): p.error(f"Source path does not exist: {args.source}")
        print(f"[+] Read-only source scan: {args.source}")
        sr,sm=run_source(args.source); results.extend(sr); meta["source"]=sm
    # Merge overlapping website/source checks so the final report has one row per skill.
    # Prefer an actionable finding over a weaker informational/not-run result.
    priority={"FAIL":5,"WARN":4,"PASS":3,"NEEDS_API":2,"NOT_RUN":1}
    merged={}
    for item in results:
        key=item["skill"]
        if key not in merged or priority.get(item["status"],0) > priority.get(merged[key]["status"],0):
            merged[key]=item
        elif item.get("evidence") and item["evidence"] not in merged[key].get("evidence",""):
            merged[key]["evidence"] += " | " + item["evidence"]
    results=list(merged.values())
    # Add explicit registry coverage records for any skill not represented by the implemented checkers.
    represented={r["skill"] for r in results}
    for category,skills in ACTIVE_SKILLS.items():
        for skill in skills:
            if skill not in represented:
                results.append(result(skill,"NOT_RUN","Info",f"No dedicated executable check was run for this skill in this build. Category: {category}.",
                                      "Not assessed; absence of a result is not a pass.",
                                      "Implement or connect a dedicated scanner and validate it with test fixtures."))
    category_for={skill: category for category, skills in ACTIVE_SKILLS.items() for skill in skills}
    for item in results:
        item["category"] = category_for.get(item["skill"], "Other")
    out=write_reports(results,meta,args.output)
    print("\n=== COMPLAUDI AUDIT SUMMARY ===")
    from collections import Counter
    counts=Counter(r["status"] for r in results)
    for k in ("PASS","FAIL","WARN","NEEDS_API","NOT_RUN"): print(f"{k:10s}: {counts.get(k,0)}")
    print(f"TOTAL     : {len(results)} / {ACTIVE_TOTAL_SKILLS} active skills")
    print(f"Reports   : {out.resolve()}")
    print("Open complaudi-report.html for the visual report.")
    return 0

if __name__=="__main__":
    raise SystemExit(main())
