"""The 93 skills from Complaudi_Skills.pdf, preserved by category."""
SKILLS = {
"Performance Audit": [
"Core Web Vitals", "Page Speed Analyzer", "Resource Optimization",
"Network Performance", "Browser Performance", "Mobile Performance",
"Advanced Performance"],
"Security Audit": [
"Security Headers Checker", "SSL/TLS Certificate Checker",
"Authentication Security", "Authorization Testing",
"Sensitive Data Exposure Detection", "Hardcoded Secrets Scanner",
"SQL Injection Detection", "Cross-Site Scripting (XSS) Detection",
"Cross-Site Request Forgery (CSRF) Protection Checker",
"Security Misconfiguration Detection"],
"Vulnerability Assessment": [
"CVE Vulnerability Scanner", "Dependency Vulnerability Scanner",
"Outdated Package Detection", "OWASP Top 10 Assessment",
"API Vulnerability Scanner", "Port Scanning",
"Directory Exposure Detection", "File Upload Vulnerability Testing",
"Server Configuration Assessment", "Risk Scoring & Severity Classification"],
"SEO Audit": [
"Title Tag Analyzer", "Meta Description Analyzer",
"Heading Structure Analyzer", "Sitemap Checker", "Robots.txt Checker",
"Broken Link Checker", "Internal Link Analyzer", "Image Alt Text Checker",
"Canonical URL Checker", "Schema Markup Validator",
"Mobile SEO Analyzer", "Technical SEO Crawler"],
"AI Visibility Audit (AEO / GEO)": [
"ChatGPT Visibility Checker", "Google AI Overviews Visibility",
"Gemini Visibility Checker", "Claude Visibility Checker",
"Perplexity Visibility Checker", "Microsoft Copilot Visibility",
"Grok Visibility Checker", "Brand Mention Tracking",
"AI Citation Tracking", "Entity Recognition Analysis",
"AI Crawlability Checker", "Content Optimization for AI Search"],
"Code Quality Audit": [
"Code Complexity Analyzer", "Duplicate Code Detection", "Dead Code Detection",
"Code Smell Detection", "Naming Convention Checker",
"Error Handling Analysis", "Dependency Analysis", "Static Code Analysis",
"Maintainability Analysis", "Technical Debt Estimator"],
"Bug & Error Detection": [
"JavaScript Error Detection", "Console Error Monitoring",
"HTTP Error Detection", "Broken Page Detection", "API Error Detection",
"Form Validation Testing", "UI Bug Detection", "Runtime Error Detection",
"Cross-Browser Bug Detection"],
"Unit & Automated Testing": [
"Unit Test Runner", "Integration Testing", "API Testing",
"End-to-End Testing", "Component Testing", "Regression Testing",
"Functional Testing", "Test Coverage Analyzer",
"Automated Test Report Generator"],
"Accessibility Audit": [
"WCAG Compliance Checker", "Color Contrast Analyzer",
"Keyboard Navigation Testing", "Screen Reader Compatibility",
"Image Accessibility Checker", "ARIA Attribute Validation",
"Form Accessibility Testing", "Semantic HTML Checker"],
"Website Compatibility Audit": [
"Chrome Compatibility", "Firefox Compatibility", "Safari Compatibility",
"Edge Compatibility", "Mobile Browser Compatibility",
"Responsive Layout Testing"]
}

# These categories remain fully defined above, but are intentionally excluded from
# normal /complaudi execution, persisted results, generated reports and dashboard views.
HIDDEN_CATEGORIES = frozenset({"Performance Audit", "SEO Audit", "Accessibility Audit"})
ACTIVE_SKILLS = {category: skills for category, skills in SKILLS.items() if category not in HIDDEN_CATEGORIES}
ACTIVE_CATEGORIES = tuple(ACTIVE_SKILLS.keys())
TOTAL_SKILLS = sum(len(v) for v in SKILLS.values())
ACTIVE_TOTAL_SKILLS = sum(len(v) for v in ACTIVE_SKILLS.values())
HIDDEN_TOTAL_SKILLS = TOTAL_SKILLS - ACTIVE_TOTAL_SKILLS
HIDDEN_SKILL_NAMES = frozenset(skill for category, skills in SKILLS.items() if category in HIDDEN_CATEGORIES for skill in skills)
ACTIVE_SKILL_NAMES = frozenset(skill for skills in ACTIVE_SKILLS.values() for skill in skills)
