import json, html
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
from .registry import HIDDEN_SKILL_NAMES

def write_reports(results, metadata, output_dir):
    results = [r for r in results if r.get("skill") not in HIDDEN_SKILL_NAMES]
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    counts=Counter(r["status"] for r in results)
    summary={"generated_at":datetime.now(timezone.utc).isoformat(),"total_checks":len(results),
             "status_counts":dict(counts),"metadata":metadata,"results":results}
    (out/"complaudi-report.json").write_text(json.dumps(summary,indent=2,ensure_ascii=False),"utf-8")
    lines=["# Complaudi Audit Report","",f"Generated: {summary['generated_at']}","",
           f"**Total checks:** {len(results)}","",
           "| Status | Count |","|---|---:|"]
    for status,n in sorted(counts.items()): lines.append(f"| {status} | {n} |")
    lines += ["","## Findings","",
              "| Skill | Status | Severity | Details | Evidence | Recommendation |",
              "|---|---|---|---|---|---|"]
    for r in results:
        vals=[r.get(k,"") for k in ("skill","status","severity","details","evidence","recommendation")]
        vals=[str(v).replace("|","\\|").replace("\n"," ") for v in vals]
        lines.append("| "+" | ".join(vals)+" |")
    (out/"complaudi-report.md").write_text("\n".join(lines),"utf-8")
    rows=[]
    for r in results:
        cells="".join(f"<td>{html.escape(str(r.get(k,'')))}</td>" for k in ("skill","status","severity","details","evidence","recommendation"))
        color={"FAIL":"#fee2e2","WARN":"#fef3c7","PASS":"#dcfce7","NOT_RUN":"#e5e7eb","NEEDS_API":"#dbeafe"}.get(r["status"],"#fff")
        rows.append(f"<tr style='background:{color}'>{cells}</tr>")
    page=f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width'>
<title>Complaudi Audit Report</title><style>
body{{font:14px system-ui;margin:24px;color:#172033}}h1{{margin-bottom:4px}}
.note{{background:#fff7ed;padding:12px;border-left:4px solid #f59e0b}}
table{{border-collapse:collapse;width:100%;font-size:12px}}th,td{{border:1px solid #ddd;padding:8px;text-align:left;vertical-align:top}}th{{background:#e5e7eb;position:sticky;top:0}}
</style></head><body><h1>Complaudi Audit Report</h1><p>Generated {html.escape(summary['generated_at'])}</p>
<div class='note'>Read-only checks only. NOT_RUN and NEEDS_API are not passes. Heuristic findings require manual validation. No intrusive exploit payloads or broad port scans were performed.</div>
<h2>Summary</h2><pre>{html.escape(json.dumps(dict(counts),indent=2))}</pre>
<h2>Individual checks ({len(results)})</h2><table><thead><tr><th>Skill</th><th>Status</th><th>Severity</th><th>Details</th><th>Evidence</th><th>Recommendation</th></tr></thead><tbody>{''.join(rows)}</tbody></table></body></html>"""
    (out/"complaudi-report.html").write_text(page,"utf-8")
    return out
