from __future__ import annotations
import re, json, os, ssl, socket, ipaddress, time, urllib.request, urllib.error
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse
from collections import Counter
from .registry import HIDDEN_CATEGORIES

UA = "ComplaudiAuditor/1.0 (+read-only audit; contact site owner)"
TIMEOUT = 15
MAX_PAGE_BYTES = 2_000_000
MAX_ASSET_BYTES = 1_000_000

class PageParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title_parts=[]; self.in_title=False
        self.meta=[]; self.links=[]; self.images=[]; self.headings=[]
        self.forms=[]; self.inputs=[]; self.scripts=[]; self.styles=[]
        self.text=[]; self.tags=Counter(); self.viewport=False
        self.canonical=[]; self.jsonld=[]; self.robots_meta=[]
        self.current_heading=None; self.current_form=None; self.form_depth=0
        self.buttons=0; self.landmarks=Counter(); self.aria=[]
    def handle_starttag(self, tag, attrs):
        a=dict(attrs); self.tags[tag]+=1
        if tag=="title": self.in_title=True
        if tag=="meta":
            self.meta.append(a)
            if a.get("name","").lower()=="viewport": self.viewport=True
            if a.get("name","").lower()=="robots": self.robots_meta.append(a.get("content",""))
        if tag=="link":
            self.links.append(a)
            if a.get("rel","").lower()=="canonical": self.canonical.append(a.get("href",""))
        if tag=="img": self.images.append(a)
        if tag in ("h1","h2","h3","h4","h5","h6"):
            self.current_heading=[tag,[]]; self.headings.append(self.current_heading)
        if tag=="form":
            self.current_form={"attrs":a,"inputs":[]}; self.forms.append(self.current_form)
        if tag in ("input","select","textarea","button"):
            self.inputs.append((tag,a))
            if self.current_form is not None: self.current_form["inputs"].append((tag,a))
        if tag=="script":
            self.scripts.append(a)
            if a.get("type","").lower()=="application/ld+json": self._jsonld_active=True; self._jsonld_buf=""
        if tag=="style": self.styles.append(a)
        if tag in ("header","nav","main","footer","aside"): self.landmarks[tag]+=1
        if "aria-" in " ".join(a.keys()): self.aria.append((tag,a))
        if tag=="button": self.buttons+=1
    def handle_endtag(self, tag):
        if tag=="title": self.in_title=False
        if tag in ("h1","h2","h3","h4","h5","h6"): self.current_heading=None
        if tag=="form": self.current_form=None
        if tag=="script" and getattr(self,"_jsonld_active",False):
            self.jsonld.append(getattr(self,"_jsonld_buf","")); self._jsonld_active=False
    def handle_data(self, data):
        if self.in_title: self.title_parts.append(data)
        if self.current_heading is not None: self.current_heading[1].append(data)
        if data.strip(): self.text.append(data.strip())
        if getattr(self,"_jsonld_active",False): self._jsonld_buf += data

def result(skill, status, severity="Info", details="", evidence="", recommendation=""):
    return {"skill":skill,"status":status,"severity":severity,"details":details,
            "evidence":evidence,"recommendation":recommendation}

def fetch(url, method="GET", max_bytes=MAX_PAGE_BYTES):
    req=urllib.request.Request(url, method=method, headers={"User-Agent":UA, "Accept":"text/html,*/*"})
    start=time.perf_counter()
    try:
        with SAFE_OPENER.open(req, timeout=TIMEOUT) as r:
            body=r.read(max_bytes+1)
            return {"ok":True,"status":r.status,"headers":dict(r.headers.items()),
                    "body":body[:max_bytes],"truncated":len(body)>max_bytes,
                    "elapsed_ms":round((time.perf_counter()-start)*1000,2),
                    "final_url":r.geturl()}
    except urllib.error.HTTPError as e:
        return {"ok":False,"status":e.code,"headers":dict(e.headers.items()),"body":e.read(max_bytes),
                "elapsed_ms":round((time.perf_counter()-start)*1000,2),"error":str(e),"final_url":url}
    except Exception as e:
        return {"ok":False,"status":None,"headers":{},"body":b"","elapsed_ms":round((time.perf_counter()-start)*1000,2),
                "error":str(e),"final_url":url}

def norm_url(url):
    p=urlparse(url)
    if p.scheme not in ("http","https") or not p.hostname: raise ValueError("Target must be an absolute http:// or https:// URL")
    host=p.hostname.strip("[]").lower()
    if host in ("localhost", "localhost.localdomain") or host.endswith(".local"):
        raise ValueError("Local and private network targets are not allowed by the hosted auditor")
    try:
        addresses=[ipaddress.ip_address(host)]
    except ValueError:
        try:
            addresses=[ipaddress.ip_address(item[4][0]) for item in socket.getaddrinfo(host, p.port or (443 if p.scheme=="https" else 80), type=socket.SOCK_STREAM)]
        except OSError as exc:
            raise ValueError(f"Could not resolve target host: {exc}") from exc
    if not addresses or any(not addr.is_global for addr in addresses):
        raise ValueError("Target host must resolve exclusively to public IP addresses")
    return url

class SafeRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        norm_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)

SAFE_OPENER=urllib.request.build_opener(SafeRedirectHandler())

def source_files(source):
    p=Path(source)
    if p.is_file(): return [p]
    out=[]
    ignored={".git","node_modules","dist","build",".next","coverage",".venv","venv","vendor","__pycache__"}
    for base, dirs, names in os.walk(p):
        dirs[:] = [d for d in dirs if d not in ignored]
        for n in names:
            f=Path(base)/n
            if f.suffix.lower() in {".js",".jsx",".ts",".tsx",".py",".php",".java",".go",".rb",".env",".json",".yml",".yaml",".toml",".ini",".sql",".html"} and f.stat().st_size < 2_000_000:
                out.append(f)
    return out

def run_website(url, deep=False):
    out=[]; url=norm_url(url)
    page=fetch(url)
    if page["status"] is None:
        return [result("Website Reachability","FAIL","High",page.get("error","Could not fetch target"),url,"Check DNS, TLS, firewall and URL.")], None, {}
    raw=page["body"].decode("utf-8","replace")
    parser=PageParser(); parser.feed(raw)
    headers={k.lower():v for k,v in page["headers"].items()}
    title=" ".join(parser.title_parts).strip()
    metas={m.get("name","").lower():m.get("content","") for m in parser.meta}
    descriptions=[m.get("content","") for m in parser.meta if m.get("name","").lower()=="description"]
    links=[a.get("href","") for a in parser.links if a.get("href")]
    page_links=[urljoin(url,x) for x in links if x.startswith(("/", "http"))]
    same=[x for x in page_links if urlparse(x).netloc==urlparse(url).netloc]
    bodytext=" ".join(parser.text)
    if "Performance Audit" not in HIDDEN_CATEGORIES:
        # Performance
        out.append(result("Core Web Vitals","NOT_RUN","Info","Field Core Web Vitals (LCP, INP, CLS) require a real browser/Lighthouse or CrUX data source.","No browser lab or field dataset was invoked.","Run Lighthouse/CrUX for measured LCP, INP and CLS."))
        out.append(result("Page Speed Analyzer","PASS" if page["elapsed_ms"]<2500 else "WARN","Medium" if page["elapsed_ms"]>=2500 else "Info",f"Initial document response took {page['elapsed_ms']} ms.",f"HTTP {page['status']}; {len(page['body'])} bytes read.","Investigate server response time if consistently above 2.5 seconds."))
        out.append(result("Resource Optimization","WARN" if len(parser.scripts)+len(parser.styles)>30 else "PASS","Low",f"Found {len(parser.scripts)} script tags and {len(parser.styles)} style tags.","Counts only; transfer sizes and compression of each asset were not measured.","Bundle, minify and defer non-critical assets where appropriate."))
        out.append(result("Network Performance","PASS" if "content-encoding" in headers or len(page["body"])<100_000 else "WARN","Low","Checked response compression header and document size.",f"content-encoding={headers.get('content-encoding','not present')}; bytes={len(page['body'])}.","Enable Brotli/Gzip for text responses and optimize payload size."))
        out.append(result("Browser Performance","NOT_RUN","Info","Requires browser tracing and runtime metrics.","Static HTTP request only.","Run the optional Playwright/Lighthouse browser audit."))
        out.append(result("Mobile Performance","PASS" if parser.viewport else "FAIL","Medium" if not parser.viewport else "Info","Viewport meta tag "+("present." if parser.viewport else "missing."),"viewport="+str(parser.viewport),"Add a responsive viewport meta tag."))
        out.append(result("Advanced Performance","NOT_RUN","Info","Long tasks, memory, CPU and rendering traces require browser instrumentation.","Not measured.","Use Lighthouse or Playwright tracing on representative pages."))
    # Security
    required=["content-security-policy","strict-transport-security","x-content-type-options","referrer-policy","permissions-policy"]
    missing=[h for h in required if h not in headers]
    out.append(result("Security Headers Checker","FAIL" if missing else "PASS","High" if "content-security-policy" in missing else "Medium" if missing else "Info",f"Missing headers: {', '.join(missing) if missing else 'none'}.",str({h:headers.get(h) for h in required}),"Configure an appropriate CSP, HSTS (HTTPS only), nosniff, Referrer-Policy and Permissions-Policy."))
    out.append(result("SSL/TLS Certificate Checker","NOT_RUN" if urlparse(url).scheme!="https" else "PASS","High" if urlparse(url).scheme!="https" else "Info","HTTPS is "+("not used." if urlparse(url).scheme!="https" else "used; certificate chain was validated by Python's TLS client."),url,"Serve the site over HTTPS with a valid, current certificate." if urlparse(url).scheme!="https" else "Periodically verify certificate expiry and TLS configuration."))
    out.append(result("Authentication Security","NOT_RUN","Info","Public unauthenticated scan cannot validate login/session security.","No credentials supplied.","Test in a dedicated staging account with explicit authorization."))
    out.append(result("Authorization Testing","NOT_RUN","Info","Role and tenant authorization require authorized test identities.","No authenticated role tests executed.","Use separate least-privilege test accounts and verify object-level access controls."))
    sensitive_patterns=[r"(?i)-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",r"(?i)(?:api[_-]?key|secret|password)\s*[:=]\s*['\"][^'\"]{8,}"]
    matches=[p for p in sensitive_patterns if re.search(p,raw)]
    out.append(result("Sensitive Data Exposure Detection","WARN" if matches else "PASS","High" if matches else "Info","Potential sensitive-value patterns "+("found in returned HTML." if matches else "not found in returned HTML."),", ".join(matches) if matches else "No matching patterns in fetched HTML.","Review matches manually; never expose secrets in client-side assets."))
    out.append(result("Hardcoded Secrets Scanner","NOT_RUN","Info","This check is performed against local source files, not only the public HTML.","Provide --source to scan repository files.","Run the source scan against a local repository checkout."))
    out.append(result("SQL Injection Detection","NOT_RUN","Info","A live URL-only check cannot safely prove SQL injection without authorized test inputs and application context.","No injection payloads sent.","Use static source analysis and controlled staging DAST with authorization."))
    out.append(result("Cross-Site Scripting (XSS) Detection","WARN" if re.search(r"<script[^>]*>.*?(?:document\.write|innerHTML)",raw,re.I|re.S) else "NOT_RUN","Medium","Only a lightweight returned-HTML heuristic was used; this is not an XSS exploit test.","No payloads submitted.","Use contextual output encoding, CSP and authorized DAST."))
    forms_with_post=[f for f in parser.forms if f["attrs"].get("method","get").lower()=="post"]
    csrf_missing=[]
    for f in forms_with_post:
        if not any(re.search(r"csrf|xsrf|token",str(a),re.I) for _,a in f["inputs"]): csrf_missing.append(f)
    out.append(result("Cross-Site Request Forgery (CSRF) Protection Checker","WARN" if csrf_missing else "NOT_RUN" if not forms_with_post else "PASS","Medium","POST forms without an obvious CSRF field: "+str(len(csrf_missing)),"Heuristic form-field inspection only; framework tokens may be supplied elsewhere.","Verify server-side CSRF protection or SameSite cookie strategy for state-changing requests."))
    out.append(result("Security Misconfiguration Detection","WARN" if "server" in headers and headers.get("server") else "PASS","Low","Checked for server banner disclosure.",f"Server header: {headers.get('server','not disclosed')}","Consider minimizing version/banner disclosure; this alone does not establish a vulnerability."))
    # Vulnerability
    for skill,detail in [
        ("CVE Vulnerability Scanner","Requires dependency inventory plus a current vulnerability database."),
        ("Dependency Vulnerability Scanner","Requires local lockfiles and an advisory database/tool such as OSV or Trivy."),
        ("Outdated Package Detection","Requires package manifests and current registry metadata."),
        ("OWASP Top 10 Assessment","Requires source review and authenticated, scoped testing."),
        ("API Vulnerability Scanner","Requires API specification and authorized test credentials."),
        ("Port Scanning","Not run: intrusive network scanning is disabled by default."),
        ("File Upload Vulnerability Testing","Requires an authorized test account and upload workflow."),
    ]:
        out.append(result(skill,"NOT_RUN","Info",detail,"No intrusive payloads or broad network probes were sent.","Run only in a written, authorized test scope."))
    # Directory exposure only known safe paths
    exposed=[]
    if deep:
        for path in ("/.env","/.git/config","/backup.zip","/phpinfo.php"):
            r=fetch(urljoin(url,path),max_bytes=20000)
            if r["status"]==200 and r["body"]:
                exposed.append(f"{path} (HTTP 200)")
    out.append(result("Directory Exposure Detection","WARN" if exposed else "PASS" if deep else "NOT_RUN","High" if exposed else "Info","Potentially sensitive common paths: "+(", ".join(exposed) if exposed else "none found" if deep else "deep checks disabled"),"Only four fixed paths were requested; no directory brute force.","Block public access to configuration, VCS and backup files."))
    out.append(result("Server Configuration Assessment","WARN" if "x-powered-by" in headers else "PASS","Low","Checked common technology disclosure header.",f"X-Powered-By: {headers.get('x-powered-by','not disclosed')}","Remove unnecessary technology disclosure and review server hardening."))
    out.append(result("Risk Scoring & Severity Classification","PASS","Info","Findings are severity-labelled in this report.","Risk score is derived from observed findings only; it is not a certification.","Prioritize confirmed High and Critical findings and validate warnings."))
    # Shared inputs used by active AI-visibility checks; these are not emitted as SEO skill results.
    robots=fetch(urljoin(url,"/robots.txt"),max_bytes=100000)
    valid_jsonld=False
    for item in parser.jsonld:
        try: json.loads(item); valid_jsonld=True
        except Exception: pass
    if "SEO Audit" not in HIDDEN_CATEGORIES:
        # SEO
        def add(skill, ok, detail, evidence="", rec="", severity="Medium"):
            out.append(result(skill,"PASS" if ok else "FAIL",severity,detail,evidence,rec))
        add("Title Tag Analyzer",bool(title) and len(title)<=60,f"Title length: {len(title)}.",title,"Add a unique, descriptive title (commonly 30–60 characters).")
        add("Meta Description Analyzer",bool(descriptions and descriptions[0].strip()),"Meta description "+("present." if descriptions and descriptions[0].strip() else "missing."),descriptions[0] if descriptions else "none","Add a concise, unique meta description.")
        h1=[h for tag,h in parser.headings if tag=="h1"]
        add("Heading Structure Analyzer",len(h1)==1,f"Found {len(h1)} H1 headings.", " | ".join(" ".join(x) for x in h1),"Use a clear heading hierarchy and normally one primary H1.")
        add("Sitemap Checker",sitemap["status"]==200 and b"<" in sitemap["body"],"Checked /sitemap.xml.",f"HTTP {sitemap['status']}","Publish a valid XML sitemap and reference it in robots.txt.")
        add("Robots.txt Checker",robots["status"]==200,"Checked /robots.txt.",f"HTTP {robots['status']}","Publish a valid robots.txt; ensure important pages are crawlable.")
        # link checks: HEAD only limited 25 same-origin links, deep flag
        if deep:
            broken=[]
            for link in same[:25]:
                r=fetch(link,"HEAD",1000)
                if r["status"] and r["status"]>=400: broken.append(f"{link} ({r['status']})")
            add("Broken Link Checker",not broken,f"Checked {min(len(same),25)} same-origin links; broken: {len(broken)}.", "; ".join(broken[:10]),"Repair or redirect broken internal links.")
        else:
            out.append(result("Broken Link Checker","NOT_RUN","Info","Enable --deep to check up to 25 same-origin links.","No link targets were requested.","Run a deeper crawl on an authorized target."))
        add("Internal Link Analyzer",len(same)>0,f"Found {len(same)} same-origin links.",str(same[:10]),"Ensure key pages are reachable through descriptive internal links.")
        add("Image Alt Text Checker",not no_alt,f"Images without non-empty alt text: {len(no_alt)}.",str(no_alt[:10]),"Add meaningful alt text; use empty alt for decorative images.")
        add("Canonical URL Checker",len(parser.canonical)==1 and bool(parser.canonical[0]),f"Canonical tags found: {len(parser.canonical)}.",str(parser.canonical),"Provide one absolute canonical URL where appropriate.")
        add("Schema Markup Validator",valid_jsonld,"Valid JSON-LD syntax "+("found." if valid_jsonld else "not found or invalid."),str(parser.jsonld[:1]),"Add valid JSON-LD structured data appropriate to the page.")
        add("Mobile SEO Analyzer",parser.viewport,"Viewport meta tag "+("present." if parser.viewport else "missing."),str(parser.viewport),"Use a responsive viewport and mobile-friendly layout.")
        add("Technical SEO Crawler",page["status"]==200,f"Homepage HTTP status: {page['status']}; internal links discovered: {len(same)}.",url,"Crawl key indexable pages and review canonical, robots, status and internal linking.")
    # AI visibility
    ai_bots=["GPTBot","OAI-SearchBot","Google-Extended","ClaudeBot","PerplexityBot","CCBot"]
    robots_text=robots["body"].decode("utf-8","replace")
    allowed=[b for b in ai_bots if re.search(r"(?im)^User-agent:\s*"+re.escape(b)+r"\s*$",robots_text)]
    out.append(result("AI Crawlability Checker","PASS" if allowed else "WARN","Low","AI crawler-specific user-agent rules "+("found: "+", ".join(allowed) if allowed else "not explicitly found in robots.txt."),robots_text[:1200],"Review AI crawler access policies and publish a clear llms.txt if useful."))
    out.append(result("Entity Recognition Analysis","WARN" if valid_jsonld else "NOT_RUN","Low","Structured data "+("exists; entity quality still needs review." if valid_jsonld else "not detected."),str(parser.jsonld[:1]),"Use consistent Organization, Product and WebSite entities where relevant."))
    out.append(result("Content Optimization for AI Search","WARN","Info","Basic text was extracted; semantic completeness, factuality and citation-worthiness require editorial review.",bodytext[:500],"Use clear answer-first sections, attributable facts, descriptive headings and authoritative references."))
    for s in ["ChatGPT Visibility Checker","Google AI Overviews Visibility","Gemini Visibility Checker","Claude Visibility Checker","Perplexity Visibility Checker","Microsoft Copilot Visibility","Grok Visibility Checker","Brand Mention Tracking","AI Citation Tracking"]:
        out.append(result(s,"NEEDS_API","Info","Requires platform API access, a controlled query set, or third-party monitoring; not inferable from a single website fetch.","No AI platform queries were submitted.","Configure approved APIs and a repeatable query/competitor measurement set."))
    # Bug checks
    out.append(result("HTTP Error Detection","PASS" if page["status"]<400 else "FAIL","High" if page["status"]>=500 else "Medium",f"Homepage returned HTTP {page['status']}.",page["final_url"],"Resolve non-success responses and inspect server logs."))
    out.append(result("Broken Page Detection","NOT_RUN","Info","A complete route inventory and browser crawl are required.","Only homepage fetched.","Enable deep crawl and provide important route list."))
    out.append(result("API Error Detection","NOT_RUN","Info","No API endpoints were supplied or invoked.","No API requests beyond homepage/robots/sitemap.","Provide OpenAPI spec or authorized endpoint list."))
    out.append(result("Form Validation Testing","NOT_RUN","Info","Form submission tests can create or modify data and require test accounts.","No forms submitted.","Test forms in staging with test data only."))
    out.append(result("UI Bug Detection","NOT_RUN","Info","Requires browser rendering and visual comparison.","No browser session.","Run Playwright visual checks on target browsers.")
    )
    out.append(result("JavaScript Error Detection","NOT_RUN","Info","Requires browser runtime console capture.","No JS executed.","Run Playwright with console/pageerror listeners."))
    out.append(result("Console Error Monitoring","NOT_RUN","Info","Requires browser console capture.","No browser session.","Run browser-based monitoring.")
    )
    out.append(result("Runtime Error Detection","NOT_RUN","Info","Requires runtime instrumentation.","Static HTTP fetch only.","Run controlled browser and server-side test suites."))
    out.append(result("Cross-Browser Bug Detection","NOT_RUN","Info","Requires multiple browser engines.","No browser engines launched.","Use Playwright Chromium, Firefox and WebKit where available."))
    if "Accessibility Audit" not in HIDDEN_CATEGORIES:
        # accessibility
        add("WCAG Compliance Checker",False,"A complete WCAG conformance result requires automated and manual testing.","Only selected static checks are included; no conformance claim.","Run axe-core plus manual WCAG 2.2 AA review.")
        contrast="NOT_RUN"
        out.append(result("Color Contrast Analyzer",contrast,"Info","Computed styles and rendered colors require a browser.","Not measured.","Use axe-core or browser computed styles and verify contrast ratios."))
        out.append(result("Keyboard Navigation Testing","NOT_RUN","Info","Requires interactive keyboard traversal in a browser.","Not tested.","Test all controls with Tab, Shift+Tab, Enter, Space and Escape."))
        out.append(result("Screen Reader Compatibility","NOT_RUN","Info","Requires assistive technology and manual review.","Not tested.","Test with NVDA/VoiceOver/TalkBack and inspect accessible names."))
        add("Image Accessibility Checker",not no_alt,f"Images missing alt attributes/text: {len(no_alt)}.",str(no_alt[:10]),"Provide appropriate alternative text.")
        add("ARIA Attribute Validation",True,f"Found {len(parser.aria)} elements with ARIA attributes; semantic validity not fully evaluated.",str(parser.aria[:10]),"Validate ARIA roles, states and accessible-name computation.")
        out.append(result("Form Accessibility Testing","NOT_RUN","Info","Label associations and error announcements require deeper DOM/browser review.","Forms found: "+str(len(parser.forms)),"Associate labels, instructions and accessible error messages with controls."))
        add("Semantic HTML Checker",all(parser.landmarks.get(x,0)>0 for x in ("main",)),f"Main landmark count: {parser.landmarks.get('main',0)}.",str(parser.landmarks),"Use semantic landmarks and native elements.")
    # compatibility
    for s in ["Chrome Compatibility","Firefox Compatibility","Safari Compatibility","Edge Compatibility","Mobile Browser Compatibility","Responsive Layout Testing"]:
        out.append(result(s,"NOT_RUN","Info","Requires real browser engines/device emulation; not inferred from HTTP response.","No browser compatibility suite was launched.","Install Playwright browsers and run the optional browser audit."))
    meta={"url":url,"status":page["status"],"response_ms":page["elapsed_ms"],"bytes":len(page["body"]),
          "title":title,"same_origin_links":len(same),"images":len(parser.images),"forms":len(parser.forms),
          "headers":headers,"robots_status":robots["status"]}
    return out, parser, meta

SECRET_PATTERNS = [
("Private key",r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
("AWS access key",r"\bAKIA[0-9A-Z]{16}\b"),
("Generic API token",r"(?i)(?:api[_-]?key|secret|access[_-]?token)\s*[:=]\s*['\"][A-Za-z0-9_\-\/+=]{12,}['\"]"),
("Hardcoded password",r"(?i)(?:password|passwd)\s*[:=]\s*['\"][^'\"]{6,}['\"]"),
]
def run_source(source):
    out=[]; files=source_files(source)
    contents={}
    for f in files:
        try: contents[f]=f.read_text("utf-8",errors="ignore")
        except Exception: pass
    alltext="\n".join(contents.values())
    secret_hits=[]
    for f,txt in contents.items():
        for label,pat in SECRET_PATTERNS:
            for m in re.finditer(pat,txt):
                secret_hits.append(f"{f}:{txt.count(chr(10),0,m.start())+1}: {label}")
    out.append(result("Hardcoded Secrets Scanner","FAIL" if secret_hits else "PASS","Critical" if secret_hits else "Info",f"Potential secret matches: {len(secret_hits)}.", "; ".join(secret_hits[:20]),"Rotate exposed credentials immediately; move secrets to a secure secret manager and add scanning to CI."))
    # source-level heuristic checks
    sql_hits=[]; xss_hits=[]; smells=[]; complexity=[]
    for f,txt in contents.items():
        if f.suffix.lower() in {".js",".jsx",".ts",".tsx",".py",".php",".java"}:
            if re.search(r"(?i)(execute|query)\s*\(\s*['\"].*(\+|%s|\$\{)",txt): sql_hits.append(str(f))
            if re.search(r"(?i)(innerHTML\s*=|dangerouslySetInnerHTML|document\.write\s*\()",txt): xss_hits.append(str(f))
            if "except:" in txt or "catch (e)" in txt: smells.append(str(f))
            if txt.count("if ") + txt.count("for ") + txt.count("while ") > 80: complexity.append(str(f))
    out.append(result("SQL Injection Detection","WARN" if sql_hits else "PASS","High" if sql_hits else "Info","Potential unsafe query construction patterns: "+str(len(sql_hits)),", ".join(sql_hits[:20]),"Use parameterized queries and ORM parameter binding; manually validate flagged locations."))
    out.append(result("Cross-Site Scripting (XSS) Detection","WARN" if xss_hits else "PASS","High" if xss_hits else "Info","Potential unsafe HTML sinks: "+str(len(xss_hits)),", ".join(xss_hits[:20]),"Avoid unsafe HTML sinks or sanitize with a vetted library; verify data flow and context."))
    out.append(result("Code Smell Detection","WARN" if smells else "PASS","Low","Broad exception/catch patterns in "+str(len(set(smells)))+" files.",", ".join(sorted(set(smells))[:20]),"Handle expected errors explicitly and preserve useful diagnostics."))
    out.append(result("Code Complexity Analyzer","WARN" if complexity else "NOT_RUN","Low","Files with high simple control-flow keyword counts: "+str(len(complexity)),", ".join(complexity[:20]),"Use a language-aware complexity tool for function-level cyclomatic complexity."))
    # Dependency manifests
    manifests=[f for f in contents if f.name in ("package.json","requirements.txt","pyproject.toml","Pipfile","Gemfile","go.mod","Cargo.toml")]
    out.append(result("Dependency Analysis","PASS" if manifests else "WARN","Info",f"Dependency manifests found: {len(manifests)}.",", ".join(str(x) for x in manifests),"Review direct and transitive dependencies and lockfile consistency."))
    out.append(result("Dependency Vulnerability Scanner","NOT_RUN","Info","No live vulnerability advisory database queried by this offline scanner.",", ".join(str(x) for x in manifests),"Run OSV-Scanner, Trivy or npm audit against lockfiles."))
    out.append(result("CVE Vulnerability Scanner","NOT_RUN","Info","Requires package resolution and current CVE/advisory feeds.","No CVE database bundled.","Run an up-to-date dependency scanner.")
    )
    out.append(result("Outdated Package Detection","NOT_RUN","Info","Requires current package registry metadata.","Manifests detected: "+str(len(manifests)),"Compare pinned versions against official registries.")
    )
    out.append(result("Static Code Analysis","PASS","Info",f"Read {len(files)} source/config files; heuristic checks only.","Extensions: "+str(Counter(f.suffix for f in files)),"Add language-specific linters and SAST tools for deeper coverage.")
    )
    out.append(result("Duplicate Code Detection","NOT_RUN","Info","Token-aware clone detection is not included in this lightweight build.","No clone detector executed.","Use jscpd or a language-aware clone detector.")
    )
    out.append(result("Dead Code Detection","NOT_RUN","Info","Reliable dead-code detection requires language/module graph analysis.","Not analyzed.","Use TypeScript compiler, ESLint and bundler analysis.")
    )
    out.append(result("Naming Convention Checker","NOT_RUN","Info","Naming rules are language- and project-specific.","No style configuration inferred.","Configure ESLint/Pylint rules to match project conventions.")
    )
    out.append(result("Error Handling Analysis","WARN" if smells else "PASS","Low","Broad catch/except patterns: "+str(len(set(smells))),", ".join(sorted(set(smells))[:20]),"Avoid swallowing exceptions; log safely and return consistent errors.")
    )
    out.append(result("Maintainability Analysis","NOT_RUN","Info","Requires language-aware maintainability metrics and project rules.","Not calculated.","Use SonarQube or equivalent for maintainability index and hotspots.")
    )
    out.append(result("Technical Debt Estimator","NOT_RUN","Info","No calibrated remediation-time model is bundled.","Not estimated.","Use measured issue counts and agreed remediation estimates.")
    )
    # test discovery
    testfiles=[f for f in files if re.search(r"(^|/)(tests?|__tests__)(/|$)|\.(test|spec)\.",str(f),re.I)]
    out.append(result("Unit Test Runner","NOT_RUN","Info","Tests are discovered but never executed automatically for safety.","Discovered test-like files: "+str(len(testfiles)),"Run the project's test command in an isolated environment after reviewing it.")
    )
    for s in ["Integration Testing","API Testing","End-to-End Testing","Component Testing","Regression Testing","Functional Testing"]:
        out.append(result(s,"NOT_RUN","Info","Requires project-specific test commands, fixtures, environment variables and often a test database.","No tests executed.","Configure explicit safe test commands and disposable test services.")
    )
    out.append(result("Test Coverage Analyzer","NOT_RUN","Info","Coverage artifacts were not generated or parsed.","No coverage report detected.","Run tests with coverage and provide lcov/cobertura output.")
    )
    out.append(result("Automated Test Report Generator","PASS","Info","This auditor generates its own consolidated report; it does not claim the application's tests passed.",f"Files scanned: {len(files)}; test files discovered: {len(testfiles)}","Run application tests separately and attach their machine-readable reports.")
    )
    # source-specific supplementary
    out.append(result("Sensitive Data Exposure Detection","PASS","Info","Secret-pattern scan completed against selected source/config files.",f"Files scanned: {len(files)}","Review all findings and exclude sensitive files from public bundles."))
    out.append(result("OWASP Top 10 Assessment","NOT_RUN","Info","Static heuristics are not a complete OWASP Top 10 assessment.","Partial SQLi/XSS checks only.","Combine SAST, dependency scanning, secure design review and authorized DAST.")
    )
    out.append(result("Risk Scoring & Severity Classification","PASS","Info","Severity labels assigned to detected heuristic findings.","Heuristic risk labels; validate manually.","Triage confirmed findings before remediation.")
    )
    return out, {"source":str(source),"files_scanned":len(files),"test_files_discovered":len(testfiles),
                 "manifests":[str(x) for x in manifests],"secret_matches":secret_hits[:50]}
