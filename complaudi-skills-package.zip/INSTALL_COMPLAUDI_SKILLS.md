# Install Complaudi Skills Extension

This is an additive extension. Copy only `.claude/commands/complaudi.md` and the `complaudi_skills/` directory into the root of your existing `complaudi-master` project. Do not replace any existing files.

## Install from the project root

```bash
# Run from /mnt/c/Users/Satheesh/Desktop/complaudi-master
mkdir -p .claude/commands
# Copy the supplied .claude/commands/complaudi.md into this path.
# Copy the supplied complaudi_skills directory into this project root.

python3 --version
python3 -m complaudi_skills.core.engine --project .
```

Then start Claude Code from this project root:

```bash
claude
```

Run:

```text
/complaudi
```

## Safety and scope

- No existing application files, package manifests, database schema, API routes, or CI workflows are changed by this extension.
- No Git push, commit, deploy, reset, stash, or branch checkout is performed.
- Reports are written only under `complaudi_skills/reports/`.
- The current checkout is inspected as-is; local uncommitted work is preserved.
- Some checks are environment-dependent. iOS native simulator testing requires macOS/Xcode; Android native testing requires Android SDK/emulator. Live performance/load testing requires an authorized staging URL and a configured load-testing tool. Missing prerequisites are reported as WARN rather than fabricated as passing.
